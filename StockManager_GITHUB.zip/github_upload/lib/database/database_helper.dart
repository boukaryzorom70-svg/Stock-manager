import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('stock_manager.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    // Table utilisateurs
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom TEXT NOT NULL,
        login TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin', 'employe')),
        actif INTEGER DEFAULT 1,
        created_at TEXT DEFAULT (datetime('now'))
      )
    ''');

    // Table catégories
    await db.execute('''
      CREATE TABLE categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom TEXT NOT NULL UNIQUE
      )
    ''');

    // Table produits
    await db.execute('''
      CREATE TABLE produits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reference TEXT UNIQUE,
        nom TEXT NOT NULL,
        categorie_id INTEGER NOT NULL,
        unite TEXT DEFAULT 'pièce',
        prix_achat REAL NOT NULL DEFAULT 0,
        prix_vente REAL NOT NULL DEFAULT 0,
        stock_actuel REAL DEFAULT 0,
        stock_minimum REAL DEFAULT 5,
        actif INTEGER DEFAULT 1,
        created_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (categorie_id) REFERENCES categories(id)
      )
    ''');

    // Table clients
    await db.execute('''
      CREATE TABLE clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom TEXT NOT NULL,
        telephone TEXT,
        adresse TEXT,
        credit_total REAL DEFAULT 0,
        created_at TEXT DEFAULT (datetime('now'))
      )
    ''');

    // Table entrées de stock
    await db.execute('''
      CREATE TABLE entrees (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        produit_id INTEGER NOT NULL,
        quantite REAL NOT NULL,
        prix_achat REAL NOT NULL,
        fournisseur TEXT,
        note TEXT,
        user_id INTEGER NOT NULL,
        created_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (produit_id) REFERENCES produits(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )
    ''');

    // Table ventes (en-tête)
    await db.execute('''
      CREATE TABLE ventes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        numero TEXT UNIQUE NOT NULL,
        client_id INTEGER,
        type_paiement TEXT NOT NULL CHECK(type_paiement IN ('comptant', 'credit', 'mixte')),
        montant_total REAL NOT NULL DEFAULT 0,
        montant_paye REAL NOT NULL DEFAULT 0,
        montant_credit REAL DEFAULT 0,
        statut TEXT DEFAULT 'active' CHECK(statut IN ('active', 'annulee')),
        user_id INTEGER NOT NULL,
        created_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (client_id) REFERENCES clients(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )
    ''');

    // Table lignes de vente (détails)
    await db.execute('''
      CREATE TABLE vente_lignes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vente_id INTEGER NOT NULL,
        produit_id INTEGER NOT NULL,
        quantite REAL NOT NULL,
        prix_vente REAL NOT NULL,
        prix_achat REAL NOT NULL,
        sous_total REAL NOT NULL,
        FOREIGN KEY (vente_id) REFERENCES ventes(id),
        FOREIGN KEY (produit_id) REFERENCES produits(id)
      )
    ''');

    // Table remboursements de crédit
    await db.execute('''
      CREATE TABLE remboursements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_id INTEGER NOT NULL,
        vente_id INTEGER,
        montant REAL NOT NULL,
        note TEXT,
        user_id INTEGER NOT NULL,
        created_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (client_id) REFERENCES clients(id),
        FOREIGN KEY (vente_id) REFERENCES ventes(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )
    ''');

    // Données initiales
    await _insertInitialData(db);
  }

  Future _insertInitialData(Database db) async {
    // Admin par défaut
    await db.insert('users', {
      'nom': 'Administrateur',
      'login': 'admin',
      'password': 'admin123', // À hasher en production
      'role': 'admin',
    });

    // Catégories
    await db.insert('categories', {'nom': 'Matériaux de plomberie'});
    await db.insert('categories', {'nom': 'Matériaux de plafonnage'});
    await db.insert('categories', {'nom': 'Matériaux de carrelage'});
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}

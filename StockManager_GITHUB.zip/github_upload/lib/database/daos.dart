import 'package:sqflite/sqflite.dart';
import '../database/database_helper.dart';
import '../models/models.dart';

// ==================== USER DAO ====================
class UserDao {
  final db = DatabaseHelper.instance;

  Future<User?> login(String login, String password) async {
    final database = await db.database;
    final result = await database.query(
      'users',
      where: 'login = ? AND password = ? AND actif = 1',
      whereArgs: [login, password],
    );
    if (result.isEmpty) return null;
    return User.fromMap(result.first);
  }

  Future<List<User>> getAll() async {
    final database = await db.database;
    final result = await database.query('users', where: 'actif = 1');
    return result.map((e) => User.fromMap(e)).toList();
  }

  Future<int> insert(User user) async {
    final database = await db.database;
    return await database.insert('users', user.toMap());
  }

  Future<int> update(User user) async {
    final database = await db.database;
    return await database.update('users', user.toMap(),
        where: 'id = ?', whereArgs: [user.id]);
  }

  Future<int> delete(int id) async {
    final database = await db.database;
    return await database.update('users', {'actif': 0},
        where: 'id = ?', whereArgs: [id]);
  }
}

// ==================== CATEGORIE DAO ====================
class CategorieDao {
  final db = DatabaseHelper.instance;

  Future<List<Categorie>> getAll() async {
    final database = await db.database;
    final result = await database.query('categories', orderBy: 'nom');
    return result.map((e) => Categorie.fromMap(e)).toList();
  }

  Future<int> insert(Categorie categorie) async {
    final database = await db.database;
    return await database.insert('categories', categorie.toMap());
  }
}

// ==================== PRODUIT DAO ====================
class ProduitDao {
  final db = DatabaseHelper.instance;

  Future<List<Produit>> getAll({int? categorieId, bool stockFaibleOnly = false}) async {
    final database = await db.database;
    String where = 'p.actif = 1';
    List<dynamic> whereArgs = [];

    if (categorieId != null) {
      where += ' AND p.categorie_id = ?';
      whereArgs.add(categorieId);
    }
    if (stockFaibleOnly) {
      where += ' AND p.stock_actuel <= p.stock_minimum';
    }

    final result = await database.rawQuery('''
      SELECT p.*, c.nom as categorie_nom
      FROM produits p
      LEFT JOIN categories c ON p.categorie_id = c.id
      WHERE $where
      ORDER BY p.nom
    ''', whereArgs);

    return result.map((e) => Produit.fromMap(e)).toList();
  }

  Future<Produit?> getById(int id) async {
    final database = await db.database;
    final result = await database.rawQuery('''
      SELECT p.*, c.nom as categorie_nom
      FROM produits p
      LEFT JOIN categories c ON p.categorie_id = c.id
      WHERE p.id = ?
    ''', [id]);
    if (result.isEmpty) return null;
    return Produit.fromMap(result.first);
  }

  Future<int> insert(Produit produit) async {
    final database = await db.database;
    return await database.insert('produits', produit.toMap());
  }

  Future<int> update(Produit produit) async {
    final database = await db.database;
    return await database.update('produits', produit.toMap(),
        where: 'id = ?', whereArgs: [produit.id]);
  }

  Future<int> updateStock(int id, double newStock, {Transaction? txn}) async {
    final database = txn ?? await db.database;
    return await database.update(
      'produits',
      {'stock_actuel': newStock},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> delete(int id) async {
    final database = await db.database;
    return await database.update('produits', {'actif': 0},
        where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Produit>> getStockFaible() async {
    return getAll(stockFaibleOnly: true);
  }
}

// ==================== CLIENT DAO ====================
class ClientDao {
  final db = DatabaseHelper.instance;

  Future<List<Client>> getAll({bool avecCreditOnly = false}) async {
    final database = await db.database;
    String? where = avecCreditOnly ? 'credit_total > 0' : null;
    final result = await database.query('clients',
        where: where, orderBy: 'nom');
    return result.map((e) => Client.fromMap(e)).toList();
  }

  Future<Client?> getById(int id) async {
    final database = await db.database;
    final result = await database.query('clients',
        where: 'id = ?', whereArgs: [id]);
    if (result.isEmpty) return null;
    return Client.fromMap(result.first);
  }

  Future<int> insert(Client client) async {
    final database = await db.database;
    return await database.insert('clients', client.toMap());
  }

  Future<int> update(Client client) async {
    final database = await db.database;
    return await database.update('clients', client.toMap(),
        where: 'id = ?', whereArgs: [client.id]);
  }

  Future<int> updateCredit(int id, double montant, {Transaction? txn}) async {
    final database = txn ?? await db.database;
    return await database.rawUpdate(
      'UPDATE clients SET credit_total = credit_total + ? WHERE id = ?',
      [montant, id],
    );
  }
}

// ==================== ENTREE DAO ====================
class EntreeDao {
  final db = DatabaseHelper.instance;

  Future<List<Entree>> getAll({String? dateDebut, String? dateFin}) async {
    final database = await db.database;
    String where = '1=1';
    List<dynamic> whereArgs = [];

    if (dateDebut != null) {
      where += ' AND e.created_at >= ?';
      whereArgs.add(dateDebut);
    }
    if (dateFin != null) {
      where += ' AND e.created_at <= ?';
      whereArgs.add(dateFin);
    }

    final result = await database.rawQuery('''
      SELECT e.*, p.nom as produit_nom, u.nom as user_nom
      FROM entrees e
      LEFT JOIN produits p ON e.produit_id = p.id
      LEFT JOIN users u ON e.user_id = u.id
      WHERE $where
      ORDER BY e.created_at DESC
    ''', whereArgs);

    return result.map((e) => Entree.fromMap(e)).toList();
  }

  Future<int> insert(Entree entree) async {
    final database = await db.database;
    return await database.transaction((txn) async {
      final id = await txn.insert('entrees', entree.toMap());
      // Mettre à jour le stock
      await txn.rawUpdate(
        'UPDATE produits SET stock_actuel = stock_actuel + ?, prix_achat = ? WHERE id = ?',
        [entree.quantite, entree.prixAchat, entree.produitId],
      );
      return id;
    });
  }
}

// ==================== VENTE DAO ====================
class VenteDao {
  final db = DatabaseHelper.instance;

  Future<String> _generateNumero() async {
    final database = await DatabaseHelper.instance.database;
    final result = await database.rawQuery(
        "SELECT COUNT(*) as count FROM ventes WHERE created_at >= date('now', 'start of day')");
    final count = (result.first['count'] as int) + 1;
    final now = DateTime.now();
    return 'VTE-${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}-${count.toString().padLeft(4, '0')}';
  }

  Future<List<Vente>> getAll({String? dateDebut, String? dateFin, String? statut}) async {
    final database = await DatabaseHelper.instance.database;
    String where = '1=1';
    List<dynamic> whereArgs = [];

    if (dateDebut != null) { where += ' AND v.created_at >= ?'; whereArgs.add(dateDebut); }
    if (dateFin != null) { where += ' AND v.created_at <= ?'; whereArgs.add(dateFin); }
    if (statut != null) { where += ' AND v.statut = ?'; whereArgs.add(statut); }

    final result = await database.rawQuery('''
      SELECT v.*, c.nom as client_nom, u.nom as user_nom
      FROM ventes v
      LEFT JOIN clients c ON v.client_id = c.id
      LEFT JOIN users u ON v.user_id = u.id
      WHERE $where
      ORDER BY v.created_at DESC
    ''', whereArgs);

    return result.map((e) => Vente.fromMap(e)).toList();
  }

  Future<Vente?> getById(int id) async {
    final database = await DatabaseHelper.instance.database;
    final result = await database.rawQuery('''
      SELECT v.*, c.nom as client_nom, u.nom as user_nom
      FROM ventes v
      LEFT JOIN clients c ON v.client_id = c.id
      LEFT JOIN users u ON v.user_id = u.id
      WHERE v.id = ?
    ''', [id]);
    if (result.isEmpty) return null;
    final vente = Vente.fromMap(result.first);
    vente.lignes = await getLignes(id);
    return vente;
  }

  Future<List<VenteLigne>> getLignes(int venteId) async {
    final database = await DatabaseHelper.instance.database;
    final result = await database.rawQuery('''
      SELECT vl.*, p.nom as produit_nom, p.unite as produit_unite
      FROM vente_lignes vl
      LEFT JOIN produits p ON vl.produit_id = p.id
      WHERE vl.vente_id = ?
    ''', [venteId]);
    return result.map((e) => VenteLigne.fromMap(e)).toList();
  }

  Future<int> insert(Vente vente, List<VenteLigne> lignes) async {
    final database = await DatabaseHelper.instance.database;
    return await database.transaction((txn) async {
      vente = Vente(
        numero: await _generateNumero(),
        clientId: vente.clientId,
        typePaiement: vente.typePaiement,
        montantTotal: vente.montantTotal,
        montantPaye: vente.montantPaye,
        montantCredit: vente.montantCredit,
        statut: vente.statut,
        userId: vente.userId,
      );

      final venteId = await txn.insert('ventes', vente.toMap());

      for (final ligne in lignes) {
        final l = VenteLigne(
          venteId: venteId,
          produitId: ligne.produitId,
          quantite: ligne.quantite,
          prixVente: ligne.prixVente,
          prixAchat: ligne.prixAchat,
          sousTotal: ligne.sousTotal,
        );
        await txn.insert('vente_lignes', l.toMap());
        // Déduire du stock
        await txn.rawUpdate(
          'UPDATE produits SET stock_actuel = stock_actuel - ? WHERE id = ?',
          [ligne.quantite, ligne.produitId],
        );
      }

      // Mettre à jour le crédit client si nécessaire
      if (vente.montantCredit > 0 && vente.clientId != null) {
        await txn.rawUpdate(
          'UPDATE clients SET credit_total = credit_total + ? WHERE id = ?',
          [vente.montantCredit, vente.clientId],
        );
      }

      return venteId;
    });
  }

  Future<bool> annuler(int venteId, int userId) async {
    final database = await DatabaseHelper.instance.database;
    final vente = await getById(venteId);
    if (vente == null || vente.isAnnulee) return false;

    await database.transaction((txn) async {
      await txn.update('ventes', {'statut': 'annulee'},
          where: 'id = ?', whereArgs: [venteId]);

      // Remettre le stock
      for (final ligne in vente.lignes) {
        await txn.rawUpdate(
          'UPDATE produits SET stock_actuel = stock_actuel + ? WHERE id = ?',
          [ligne.quantite, ligne.produitId],
        );
      }

      // Déduire le crédit client si applicable
      if (vente.montantCredit > 0 && vente.clientId != null) {
        await txn.rawUpdate(
          'UPDATE clients SET credit_total = credit_total - ? WHERE id = ?',
          [vente.montantCredit, vente.clientId],
        );
      }
    });

    return true;
  }
}

// ==================== DASHBOARD DAO ====================
class DashboardDao {
  final db = DatabaseHelper.instance;

  Future<Map<String, dynamic>> getStats({String? dateDebut, String? dateFin}) async {
    final database = await db.database;
    dateDebut ??= DateTime.now().toIso8601String().substring(0, 10);
    dateFin ??= DateTime.now().toIso8601String().substring(0, 10);

    // CA et bénéfice
    final ventesResult = await database.rawQuery('''
      SELECT 
        COALESCE(SUM(v.montant_total), 0) as chiffre_affaires,
        COALESCE(SUM(v.montant_paye), 0) as encaisse,
        COALESCE(SUM(v.montant_credit), 0) as en_credit,
        COUNT(*) as nb_ventes
      FROM ventes v
      WHERE v.statut = 'active'
        AND date(v.created_at) BETWEEN ? AND ?
    ''', [dateDebut, dateFin]);

    final beneficeResult = await database.rawQuery('''
      SELECT COALESCE(SUM((vl.prix_vente - vl.prix_achat) * vl.quantite), 0) as benefice
      FROM vente_lignes vl
      JOIN ventes v ON vl.vente_id = v.id
      WHERE v.statut = 'active'
        AND date(v.created_at) BETWEEN ? AND ?
    ''', [dateDebut, dateFin]);

    final stockFaible = await database.rawQuery('''
      SELECT COUNT(*) as count FROM produits WHERE stock_actuel <= stock_minimum AND actif = 1
    ''');

    final totalCredit = await database.rawQuery('''
      SELECT COALESCE(SUM(credit_total), 0) as total FROM clients WHERE credit_total > 0
    ''');

    return {
      'chiffre_affaires': ventesResult.first['chiffre_affaires'],
      'encaisse': ventesResult.first['encaisse'],
      'en_credit': ventesResult.first['en_credit'],
      'nb_ventes': ventesResult.first['nb_ventes'],
      'benefice': beneficeResult.first['benefice'],
      'produits_stock_faible': stockFaible.first['count'],
      'total_credit_clients': totalCredit.first['total'],
    };
  }
}

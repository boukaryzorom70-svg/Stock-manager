import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import '../models/models.dart';

class PdfService {
  static final _fmt = NumberFormat('#,##0', 'fr_FR');
  static final _dateFmt = DateFormat('dd/MM/yyyy HH:mm');

  // ---- Couleurs entreprise ----
  static const _primaryColor = PdfColor.fromInt(0xFF1565C0);
  static const _accentColor = PdfColor.fromInt(0xFF00897B);
  static const _lightGrey = PdfColor.fromInt(0xFFF5F5F5);
  static const _darkGrey = PdfColor.fromInt(0xFF424242);

  /// Génère et partage la facture d'une vente
  static Future<void> genererFacture(Vente vente) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (ctx) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            _buildHeader(vente),
            pw.SizedBox(height: 24),
            _buildInfoSection(vente),
            pw.SizedBox(height: 20),
            _buildTableArticles(vente),
            pw.SizedBox(height: 20),
            _buildTotaux(vente),
            pw.Spacer(),
            _buildFooter(),
          ],
        ),
      ),
    );

    await _saveAndShare(pdf, 'Facture_${vente.numero}');
  }

  /// Génère et partage un rapport journalier
  static Future<void> genererRapportJournalier({
    required Map<String, dynamic> stats,
    required List<Vente> ventes,
    required String date,
    required bool isAdmin,
  }) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (ctx) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            _buildRapportHeader(date),
            pw.SizedBox(height: 20),
            _buildStatCards(stats, isAdmin),
            pw.SizedBox(height: 20),
            _buildListeVentes(ventes, isAdmin),
            pw.Spacer(),
            _buildFooter(),
          ],
        ),
      ),
    );

    await _saveAndShare(pdf, 'Rapport_$date');
  }

  // ======= WIDGETS PDF =======

  static pw.Widget _buildHeader(Vente vente) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(16),
      decoration: pw.BoxDecoration(
        color: _primaryColor,
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Text('STOCK MANAGER',
                style: pw.TextStyle(
                    color: PdfColors.white, fontSize: 22,
                    fontWeight: pw.FontWeight.bold)),
            pw.Text('Matériaux de Construction',
                style: const pw.TextStyle(color: PdfColors.white70, fontSize: 12)),
          ]),
          pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
            pw.Text('FACTURE',
                style: pw.TextStyle(
                    color: PdfColors.white, fontSize: 18,
                    fontWeight: pw.FontWeight.bold)),
            pw.Text(vente.numero,
                style: const pw.TextStyle(color: PdfColors.white70, fontSize: 13)),
            pw.Text(
              vente.createdAt != null
                  ? _dateFmt.format(DateTime.parse(vente.createdAt!))
                  : '',
              style: const pw.TextStyle(color: PdfColors.white70, fontSize: 11),
            ),
          ]),
        ],
      ),
    );
  }

  static pw.Widget _buildInfoSection(Vente vente) {
    return pw.Row(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        // Infos paiement
        pw.Expanded(
          child: pw.Container(
            padding: const pw.EdgeInsets.all(12),
            decoration: pw.BoxDecoration(
              color: _lightGrey,
              borderRadius: pw.BorderRadius.circular(6),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('INFORMATIONS PAIEMENT',
                    style: pw.TextStyle(
                        fontWeight: pw.FontWeight.bold,
                        fontSize: 10, color: _darkGrey)),
                pw.SizedBox(height: 8),
                _infoRow('Mode', _capitalize(vente.typePaiement)),
                _infoRow('Statut', vente.isAnnulee ? 'ANNULÉE' : 'ACTIVE'),
                _infoRow('Vendeur', vente.userNom ?? '—'),
              ],
            ),
          ),
        ),
        pw.SizedBox(width: 16),
        // Infos client
        pw.Expanded(
          child: pw.Container(
            padding: const pw.EdgeInsets.all(12),
            decoration: pw.BoxDecoration(
              color: _lightGrey,
              borderRadius: pw.BorderRadius.circular(6),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('CLIENT',
                    style: pw.TextStyle(
                        fontWeight: pw.FontWeight.bold,
                        fontSize: 10, color: _darkGrey)),
                pw.SizedBox(height: 8),
                pw.Text(vente.clientNom ?? 'Client comptoir',
                    style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  static pw.Widget _buildTableArticles(Vente vente) {
    return pw.Table(
      border: pw.TableBorder.all(color: PdfColors.grey300, width: 0.5),
      columnWidths: {
        0: const pw.FlexColumnWidth(4),
        1: const pw.FlexColumnWidth(1.5),
        2: const pw.FlexColumnWidth(2),
        3: const pw.FlexColumnWidth(2),
      },
      children: [
        // En-tête
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: _primaryColor),
          children: [
            _th('DÉSIGNATION'),
            _th('QTÉ'),
            _th('PRIX UNIT.'),
            _th('TOTAL'),
          ],
        ),
        // Lignes
        ...vente.lignes.asMap().entries.map((e) {
          final i = e.key;
          final l = e.value;
          return pw.TableRow(
            decoration: pw.BoxDecoration(
              color: i % 2 == 0 ? PdfColors.white : _lightGrey,
            ),
            children: [
              _td(l.produitNom ?? ''),
              _td('${l.quantite} ${l.produitUnite ?? ''}'),
              _td('${_fmt.format(l.prixVente)} F'),
              _td('${_fmt.format(l.sousTotal)} F', bold: true),
            ],
          );
        }),
      ],
    );
  }

  static pw.Widget _buildTotaux(Vente vente) {
    return pw.Align(
      alignment: pw.Alignment.centerRight,
      child: pw.Container(
        width: 260,
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: PdfColors.grey300),
          borderRadius: pw.BorderRadius.circular(6),
        ),
        child: pw.Column(
          children: [
            _totalRow('TOTAL TTC', '${_fmt.format(vente.montantTotal)} FCFA',
                bold: true, bgColor: _primaryColor, textColor: PdfColors.white),
            _totalRow('Montant payé', '${_fmt.format(vente.montantPaye)} FCFA'),
            if (vente.montantCredit > 0)
              _totalRow('Reste à payer (crédit)',
                  '${_fmt.format(vente.montantCredit)} FCFA',
                  textColor: PdfColors.orange),
          ],
        ),
      ),
    );
  }

  static pw.Widget _buildRapportHeader(String date) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(16),
      decoration: pw.BoxDecoration(
        color: _primaryColor,
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Text('STOCK MANAGER',
                style: pw.TextStyle(
                    color: PdfColors.white, fontSize: 22,
                    fontWeight: pw.FontWeight.bold)),
            pw.Text('Matériaux de Construction',
                style: const pw.TextStyle(color: PdfColors.white70, fontSize: 12)),
          ]),
          pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
            pw.Text('RAPPORT JOURNALIER',
                style: pw.TextStyle(
                    color: PdfColors.white, fontSize: 16,
                    fontWeight: pw.FontWeight.bold)),
            pw.Text(date,
                style: const pw.TextStyle(color: PdfColors.white70, fontSize: 13)),
          ]),
        ],
      ),
    );
  }

  static pw.Widget _buildStatCards(Map<String, dynamic> stats, bool isAdmin) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(16),
      decoration: pw.BoxDecoration(
        color: _lightGrey,
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Column(
        children: [
          pw.Text('RÉSUMÉ', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 12),
          pw.Row(children: [
            _statCard('Chiffre d\'Affaires',
                '${_fmt.format(stats['chiffre_affaires'])} F', _primaryColor),
            pw.SizedBox(width: 12),
            _statCard('Ventes', '${stats['nb_ventes']}', _accentColor),
            pw.SizedBox(width: 12),
            if (isAdmin)
              _statCard('Bénéfice',
                  '${_fmt.format(stats['benefice'])} F', PdfColors.green700),
          ]),
          pw.SizedBox(height: 12),
          pw.Row(children: [
            _statCard('Encaissé',
                '${_fmt.format(stats['encaisse'])} F', PdfColors.teal700),
            pw.SizedBox(width: 12),
            _statCard('En crédit',
                '${_fmt.format(stats['en_credit'])} F', PdfColors.orange700),
          ]),
        ],
      ),
    );
  }

  static pw.Widget _buildListeVentes(List<Vente> ventes, bool isAdmin) {
    if (ventes.isEmpty) return pw.SizedBox();
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text('LISTE DES VENTES',
            style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 14)),
        pw.SizedBox(height: 8),
        pw.Table(
          border: pw.TableBorder.all(color: PdfColors.grey300, width: 0.5),
          columnWidths: {
            0: const pw.FlexColumnWidth(2),
            1: const pw.FlexColumnWidth(2),
            2: const pw.FlexColumnWidth(1.5),
            3: const pw.FlexColumnWidth(2),
          },
          children: [
            pw.TableRow(
              decoration: const pw.BoxDecoration(color: _primaryColor),
              children: [
                _th('N° VENTE'), _th('CLIENT'), _th('TYPE'), _th('MONTANT'),
              ],
            ),
            ...ventes.map((v) => pw.TableRow(
              children: [
                _td(v.numero),
                _td(v.clientNom ?? '—'),
                _td(_capitalize(v.typePaiement)),
                _td('${_fmt.format(v.montantTotal)} F',
                    color: v.isAnnulee ? PdfColors.red : PdfColors.black),
              ],
            )),
          ],
        ),
      ],
    );
  }

  static pw.Widget _buildFooter() {
    return pw.Container(
      padding: const pw.EdgeInsets.only(top: 12),
      decoration: const pw.BoxDecoration(
        border: pw.Border(top: pw.BorderSide(color: PdfColors.grey300)),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text('Stock Manager — Matériaux de Construction',
              style: const pw.TextStyle(color: PdfColors.grey, fontSize: 9)),
          pw.Text(
            'Généré le ${DateFormat('dd/MM/yyyy à HH:mm').format(DateTime.now())}',
            style: const pw.TextStyle(color: PdfColors.grey, fontSize: 9),
          ),
        ],
      ),
    );
  }

  // ===== HELPERS =====

  static pw.Widget _th(String text) => pw.Padding(
    padding: const pw.EdgeInsets.all(8),
    child: pw.Text(text,
        style: pw.TextStyle(
            color: PdfColors.white, fontWeight: pw.FontWeight.bold, fontSize: 10)),
  );

  static pw.Widget _td(String text, {bool bold = false, PdfColor? color}) =>
      pw.Padding(
        padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        child: pw.Text(text,
            style: pw.TextStyle(
                fontSize: 10,
                fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
                color: color ?? PdfColors.black)),
      );

  static pw.Widget _infoRow(String label, String value) => pw.Padding(
    padding: const pw.EdgeInsets.symmetric(vertical: 2),
    child: pw.Row(children: [
      pw.Text('$label: ', style: const pw.TextStyle(color: PdfColors.grey, fontSize: 10)),
      pw.Text(value, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10)),
    ]),
  );

  static pw.Widget _totalRow(String label, String value,
      {bool bold = false, PdfColor? bgColor, PdfColor? textColor}) =>
      pw.Container(
        color: bgColor,
        padding: const pw.EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(label,
                style: pw.TextStyle(
                    fontSize: 11,
                    fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
                    color: textColor ?? PdfColors.black)),
            pw.Text(value,
                style: pw.TextStyle(
                    fontSize: 11,
                    fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
                    color: textColor ?? PdfColors.black)),
          ],
        ),
      );

  static pw.Widget _statCard(String label, String value, PdfColor color) =>
      pw.Expanded(
        child: pw.Container(
          padding: const pw.EdgeInsets.all(10),
          decoration: pw.BoxDecoration(
            color: PdfColors.white,
            borderRadius: pw.BorderRadius.circular(6),
            border: pw.Border.all(color: color, width: 1.5),
          ),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(label, style: pw.TextStyle(fontSize: 9, color: PdfColors.grey)),
              pw.SizedBox(height: 4),
              pw.Text(value,
                  style: pw.TextStyle(
                      fontSize: 12, fontWeight: pw.FontWeight.bold, color: color)),
            ],
          ),
        ),
      );

  static String _capitalize(String s) =>
      s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);

  static Future<void> _saveAndShare(pw.Document pdf, String name) async {
    final bytes = await pdf.save();
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$name.pdf');
    await file.writeAsBytes(bytes);
    await Share.shareXFiles([XFile(file.path)], subject: name);
  }

  /// Afficher en aperçu avant partage
  static Future<void> previewFacture(Vente vente) async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (ctx) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            _buildHeader(vente),
            pw.SizedBox(height: 24),
            _buildInfoSection(vente),
            pw.SizedBox(height: 20),
            _buildTableArticles(vente),
            pw.SizedBox(height: 20),
            _buildTotaux(vente),
            pw.Spacer(),
            _buildFooter(),
          ],
        ),
      ),
    );
    await Printing.layoutPdf(onLayout: (_) async => await pdf.save());
  }
}

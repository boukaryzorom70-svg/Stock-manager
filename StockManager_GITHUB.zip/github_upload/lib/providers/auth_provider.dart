import 'package:flutter/material.dart';
import '../models/models.dart';
import '../database/daos.dart';

class AuthProvider extends ChangeNotifier {
  User? _currentUser;
  final _userDao = UserDao();

  User? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;
  bool get isAdmin => _currentUser?.isAdmin ?? false;

  Future<String?> login(String login, String password) async {
    try {
      final user = await _userDao.login(login, password);
      if (user == null) return 'Identifiants incorrects';
      _currentUser = user;
      notifyListeners();
      return null;
    } catch (e) {
      return 'Erreur de connexion';
    }
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }
}

// ==================== USER MODEL ====================
class User {
  final int? id;
  final String nom;
  final String login;
  final String password;
  final String role; // 'admin' ou 'employe'
  final int actif;
  final String? createdAt;

  User({
    this.id,
    required this.nom,
    required this.login,
    required this.password,
    required this.role,
    this.actif = 1,
    this.createdAt,
  });

  bool get isAdmin => role == 'admin';

  Map<String, dynamic> toMap() => {
    'id': id,
    'nom': nom,
    'login': login,
    'password': password,
    'role': role,
    'actif': actif,
  };

  factory User.fromMap(Map<String, dynamic> map) => User(
    id: map['id'],
    nom: map['nom'],
    login: map['login'],
    password: map['password'],
    role: map['role'],
    actif: map['actif'] ?? 1,
    createdAt: map['created_at'],
  );
}

// ==================== CATEGORIE MODEL ====================
class Categorie {
  final int? id;
  final String nom;

  Categorie({this.id, required this.nom});

  Map<String, dynamic> toMap() => {'id': id, 'nom': nom};

  factory Categorie.fromMap(Map<String, dynamic> map) =>
      Categorie(id: map['id'], nom: map['nom']);
}

// ==================== PRODUIT MODEL ====================
class Produit {
  final int? id;
  final String? reference;
  final String nom;
  final int categorieId;
  final String unite;
  final double prixAchat;
  final double prixVente;
  final double stockActuel;
  final double stockMinimum;
  final int actif;
  final String? createdAt;
  // Jointure
  String? categorieNom;

  Produit({
    this.id,
    this.reference,
    required this.nom,
    required this.categorieId,
    this.unite = 'pièce',
    required this.prixAchat,
    required this.prixVente,
    this.stockActuel = 0,
    this.stockMinimum = 5,
    this.actif = 1,
    this.createdAt,
    this.categorieNom,
  });

  bool get isStockFaible => stockActuel <= stockMinimum;
  bool get isRupture => stockActuel <= 0;
  double get marge => prixVente - prixAchat;
  double get margePercent => prixAchat > 0 ? (marge / prixAchat) * 100 : 0;

  Map<String, dynamic> toMap() => {
    'id': id,
    'reference': reference,
    'nom': nom,
    'categorie_id': categorieId,
    'unite': unite,
    'prix_achat': prixAchat,
    'prix_vente': prixVente,
    'stock_actuel': stockActuel,
    'stock_minimum': stockMinimum,
    'actif': actif,
  };

  factory Produit.fromMap(Map<String, dynamic> map) => Produit(
    id: map['id'],
    reference: map['reference'],
    nom: map['nom'],
    categorieId: map['categorie_id'],
    unite: map['unite'] ?? 'pièce',
    prixAchat: (map['prix_achat'] as num).toDouble(),
    prixVente: (map['prix_vente'] as num).toDouble(),
    stockActuel: (map['stock_actuel'] as num).toDouble(),
    stockMinimum: (map['stock_minimum'] as num).toDouble(),
    actif: map['actif'] ?? 1,
    createdAt: map['created_at'],
    categorieNom: map['categorie_nom'],
  );
}

// ==================== CLIENT MODEL ====================
class Client {
  final int? id;
  final String nom;
  final String? telephone;
  final String? adresse;
  final double creditTotal;
  final String? createdAt;

  Client({
    this.id,
    required this.nom,
    this.telephone,
    this.adresse,
    this.creditTotal = 0,
    this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'nom': nom,
    'telephone': telephone,
    'adresse': adresse,
    'credit_total': creditTotal,
  };

  factory Client.fromMap(Map<String, dynamic> map) => Client(
    id: map['id'],
    nom: map['nom'],
    telephone: map['telephone'],
    adresse: map['adresse'],
    creditTotal: (map['credit_total'] as num).toDouble(),
    createdAt: map['created_at'],
  );
}

// ==================== ENTREE MODEL ====================
class Entree {
  final int? id;
  final int produitId;
  final double quantite;
  final double prixAchat;
  final String? fournisseur;
  final String? note;
  final int userId;
  final String? createdAt;
  // Jointures
  String? produitNom;
  String? userNom;

  Entree({
    this.id,
    required this.produitId,
    required this.quantite,
    required this.prixAchat,
    this.fournisseur,
    this.note,
    required this.userId,
    this.createdAt,
    this.produitNom,
    this.userNom,
  });

  double get montantTotal => quantite * prixAchat;

  Map<String, dynamic> toMap() => {
    'id': id,
    'produit_id': produitId,
    'quantite': quantite,
    'prix_achat': prixAchat,
    'fournisseur': fournisseur,
    'note': note,
    'user_id': userId,
  };

  factory Entree.fromMap(Map<String, dynamic> map) => Entree(
    id: map['id'],
    produitId: map['produit_id'],
    quantite: (map['quantite'] as num).toDouble(),
    prixAchat: (map['prix_achat'] as num).toDouble(),
    fournisseur: map['fournisseur'],
    note: map['note'],
    userId: map['user_id'],
    createdAt: map['created_at'],
    produitNom: map['produit_nom'],
    userNom: map['user_nom'],
  );
}

// ==================== VENTE LIGNE MODEL ====================
class VenteLigne {
  final int? id;
  final int venteId;
  final int produitId;
  final double quantite;
  final double prixVente;
  final double prixAchat;
  final double sousTotal;
  // Jointure
  String? produitNom;
  String? produitUnite;

  VenteLigne({
    this.id,
    required this.venteId,
    required this.produitId,
    required this.quantite,
    required this.prixVente,
    required this.prixAchat,
    required this.sousTotal,
    this.produitNom,
    this.produitUnite,
  });

  double get benefice => (prixVente - prixAchat) * quantite;

  Map<String, dynamic> toMap() => {
    'id': id,
    'vente_id': venteId,
    'produit_id': produitId,
    'quantite': quantite,
    'prix_vente': prixVente,
    'prix_achat': prixAchat,
    'sous_total': sousTotal,
  };

  factory VenteLigne.fromMap(Map<String, dynamic> map) => VenteLigne(
    id: map['id'],
    venteId: map['vente_id'],
    produitId: map['produit_id'],
    quantite: (map['quantite'] as num).toDouble(),
    prixVente: (map['prix_vente'] as num).toDouble(),
    prixAchat: (map['prix_achat'] as num).toDouble(),
    sousTotal: (map['sous_total'] as num).toDouble(),
    produitNom: map['produit_nom'],
    produitUnite: map['produit_unite'],
  );
}

// ==================== VENTE MODEL ====================
class Vente {
  final int? id;
  final String numero;
  final int? clientId;
  final String typePaiement; // 'comptant', 'credit', 'mixte'
  final double montantTotal;
  final double montantPaye;
  final double montantCredit;
  final String statut; // 'active', 'annulee'
  final int userId;
  final String? createdAt;
  // Jointures
  String? clientNom;
  String? userNom;
  List<VenteLigne> lignes;

  Vente({
    this.id,
    required this.numero,
    this.clientId,
    required this.typePaiement,
    required this.montantTotal,
    required this.montantPaye,
    this.montantCredit = 0,
    this.statut = 'active',
    required this.userId,
    this.createdAt,
    this.clientNom,
    this.userNom,
    this.lignes = const [],
  });

  bool get isAnnulee => statut == 'annulee';
  double get beneficeTotal => lignes.fold(0, (sum, l) => sum + l.benefice);

  Map<String, dynamic> toMap() => {
    'id': id,
    'numero': numero,
    'client_id': clientId,
    'type_paiement': typePaiement,
    'montant_total': montantTotal,
    'montant_paye': montantPaye,
    'montant_credit': montantCredit,
    'statut': statut,
    'user_id': userId,
  };

  factory Vente.fromMap(Map<String, dynamic> map) => Vente(
    id: map['id'],
    numero: map['numero'],
    clientId: map['client_id'],
    typePaiement: map['type_paiement'],
    montantTotal: (map['montant_total'] as num).toDouble(),
    montantPaye: (map['montant_paye'] as num).toDouble(),
    montantCredit: (map['montant_credit'] as num? ?? 0).toDouble(),
    statut: map['statut'] ?? 'active',
    userId: map['user_id'],
    createdAt: map['created_at'],
    clientNom: map['client_nom'],
    userNom: map['user_nom'],
  );
}

// ==================== REMBOURSEMENT MODEL ====================
class Remboursement {
  final int? id;
  final int clientId;
  final int? venteId;
  final double montant;
  final String? note;
  final int userId;
  final String? createdAt;

  Remboursement({
    this.id,
    required this.clientId,
    this.venteId,
    required this.montant,
    this.note,
    required this.userId,
    this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'client_id': clientId,
    'vente_id': venteId,
    'montant': montant,
    'note': note,
    'user_id': userId,
  };

  factory Remboursement.fromMap(Map<String, dynamic> map) => Remboursement(
    id: map['id'],
    clientId: map['client_id'],
    venteId: map['vente_id'],
    montant: (map['montant'] as num).toDouble(),
    note: map['note'],
    userId: map['user_id'],
    createdAt: map['created_at'],
  );
}

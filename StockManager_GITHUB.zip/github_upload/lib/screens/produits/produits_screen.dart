import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../database/daos.dart';
import '../../models/models.dart';
import 'produit_form_screen.dart';

class ProduitsScreen extends StatefulWidget {
  const ProduitsScreen({super.key});

  @override
  State<ProduitsScreen> createState() => _ProduitsScreenState();
}

class _ProduitsScreenState extends State<ProduitsScreen> {
  final _dao = ProduitDao();
  final _catDao = CategorieDao();
  List<Produit> _produits = [];
  List<Categorie> _categories = [];
  int? _selectedCat;
  String _search = '';
  bool _loading = true;
  final _fmt = NumberFormat('#,##0', 'fr_FR');

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    final cats = await _catDao.getAll();
    final prods = await _dao.getAll(categorieId: _selectedCat);
    if (mounted) setState(() { _categories = cats; _produits = prods; _loading = false; });
  }

  List<Produit> get _filtered => _produits.where((p) =>
      p.nom.toLowerCase().contains(_search.toLowerCase()) ||
      (p.reference?.toLowerCase().contains(_search.toLowerCase()) ?? false)
  ).toList();

  @override
  Widget build(BuildContext context) {
    final isAdmin = context.watch<AuthProvider>().isAdmin;

    return Column(
      children: [
        // Barre recherche
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            decoration: const InputDecoration(
              hintText: 'Rechercher un produit...',
              prefixIcon: Icon(Icons.search),
              contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 16),
            ),
            onChanged: (v) => setState(() => _search = v),
          ),
        ),

        // Filtre catégorie
        SizedBox(
          height: 40,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              _catChip('Tous', null),
              ..._categories.map((c) => _catChip(c.nom, c.id)),
            ],
          ),
        ),

        const SizedBox(height: 8),

        // Liste
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : RefreshIndicator(
                  onRefresh: _loadData,
                  child: _filtered.isEmpty
                      ? const Center(child: Text('Aucun produit trouvé'))
                      : ListView.builder(
                          itemCount: _filtered.length,
                          itemBuilder: (ctx, i) => _buildProduitCard(_filtered[i], isAdmin),
                        ),
                ),
        ),
      ],
    );
  }

  Widget _catChip(String label, int? id) {
    final selected = _selectedCat == id;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: FilterChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) { setState(() => _selectedCat = id); _loadData(); },
      ),
    );
  }

  Widget _buildProduitCard(Produit p, bool isAdmin) {
    Color stockColor = p.isRupture
        ? Colors.red
        : p.isStockFaible
            ? Colors.orange
            : Colors.green;

    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: stockColor.withOpacity(0.15),
          child: Icon(Icons.inventory_2, color: stockColor),
        ),
        title: Text(p.nom, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(p.categorieNom ?? '', style: const TextStyle(fontSize: 12)),
            Row(children: [
              Text('Stock: ', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
              Text('${p.stockActuel} ${p.unite}',
                  style: TextStyle(color: stockColor, fontWeight: FontWeight.bold, fontSize: 12)),
            ]),
          ],
        ),
        trailing: isAdmin
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('${_fmt.format(p.prixVente)} F',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  Text('Achat: ${_fmt.format(p.prixAchat)} F',
                      style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
                ],
              )
            : Text('${_fmt.format(p.prixVente)} F',
                style: const TextStyle(fontWeight: FontWeight.bold)),
        onTap: isAdmin
            ? () async {
                await Navigator.push(context,
                    MaterialPageRoute(builder: (_) => ProduitFormScreen(produit: p)));
                _loadData();
              }
            : null,
      ),
    );
  }
}

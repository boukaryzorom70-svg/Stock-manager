import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../database/daos.dart';
import '../../models/models.dart';

class ProduitFormScreen extends StatefulWidget {
  final Produit? produit;
  const ProduitFormScreen({super.key, this.produit});

  @override
  State<ProduitFormScreen> createState() => _ProduitFormScreenState();
}

class _ProduitFormScreenState extends State<ProduitFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _dao = ProduitDao();
  final _catDao = CategorieDao();
  List<Categorie> _categories = [];
  bool _loading = false;

  late TextEditingController _nomCtrl;
  late TextEditingController _refCtrl;
  late TextEditingController _prixAchatCtrl;
  late TextEditingController _prixVenteCtrl;
  late TextEditingController _stockCtrl;
  late TextEditingController _stockMinCtrl;
  int? _categorieId;
  String _unite = 'pièce';

  final _unites = ['pièce', 'mètre', 'mètre²', 'kg', 'litre', 'sac', 'boîte', 'rouleau'];

  @override
  void initState() {
    super.initState();
    final p = widget.produit;
    _nomCtrl = TextEditingController(text: p?.nom ?? '');
    _refCtrl = TextEditingController(text: p?.reference ?? '');
    _prixAchatCtrl = TextEditingController(text: p?.prixAchat.toString() ?? '0');
    _prixVenteCtrl = TextEditingController(text: p?.prixVente.toString() ?? '0');
    _stockCtrl = TextEditingController(text: p?.stockActuel.toString() ?? '0');
    _stockMinCtrl = TextEditingController(text: p?.stockMinimum.toString() ?? '5');
    _categorieId = p?.categorieId;
    _unite = p?.unite ?? 'pièce';
    _loadCategories();
  }

  Future<void> _loadCategories() async {
    final cats = await _catDao.getAll();
    if (mounted) setState(() => _categories = cats);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_categorieId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Veuillez sélectionner une catégorie')));
      return;
    }

    setState(() => _loading = true);
    try {
      final produit = Produit(
        id: widget.produit?.id,
        nom: _nomCtrl.text.trim(),
        reference: _refCtrl.text.trim().isEmpty ? null : _refCtrl.text.trim(),
        categorieId: _categorieId!,
        unite: _unite,
        prixAchat: double.parse(_prixAchatCtrl.text),
        prixVente: double.parse(_prixVenteCtrl.text),
        stockActuel: double.parse(_stockCtrl.text),
        stockMinimum: double.parse(_stockMinCtrl.text),
      );

      if (widget.produit == null) {
        await _dao.insert(produit);
      } else {
        await _dao.update(produit);
      }

      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Erreur: $e'), backgroundColor: Colors.red));
      }
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.produit != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Modifier produit' : 'Nouveau produit'),
        actions: [
          if (isEdit)
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: _confirmDelete,
            ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            _field(_nomCtrl, 'Nom du produit *', required: true),
            _field(_refCtrl, 'Référence'),
            // Catégorie
            DropdownButtonFormField<int>(
              value: _categorieId,
              decoration: const InputDecoration(labelText: 'Catégorie *'),
              items: _categories
                  .map((c) => DropdownMenuItem(value: c.id, child: Text(c.nom)))
                  .toList(),
              onChanged: (v) => setState(() => _categorieId = v),
              validator: (v) => v == null ? 'Requis' : null,
            ),
            const SizedBox(height: 16),
            // Unité
            DropdownButtonFormField<String>(
              value: _unite,
              decoration: const InputDecoration(labelText: 'Unité'),
              items: _unites
                  .map((u) => DropdownMenuItem(value: u, child: Text(u)))
                  .toList(),
              onChanged: (v) => setState(() => _unite = v!),
            ),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: _numField(_prixAchatCtrl, 'Prix achat (FCFA) *')),
              const SizedBox(width: 12),
              Expanded(child: _numField(_prixVenteCtrl, 'Prix vente (FCFA) *')),
            ]),
            const SizedBox(height: 4),
            Row(children: [
              Expanded(child: _numField(_stockCtrl, 'Stock initial')),
              const SizedBox(width: 12),
              Expanded(child: _numField(_stockMinCtrl, 'Stock minimum')),
            ]),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _loading ? null : _save,
                child: _loading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : Text(isEdit ? 'MODIFIER' : 'ENREGISTRER'),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _field(TextEditingController ctrl, String label, {bool required = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: ctrl,
        decoration: InputDecoration(labelText: label),
        validator: required ? (v) => v!.isEmpty ? 'Requis' : null : null,
      ),
    );
  }

  Widget _numField(TextEditingController ctrl, String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: ctrl,
        decoration: InputDecoration(labelText: label),
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[\d.]'))],
        validator: (v) {
          if (v == null || v.isEmpty) return 'Requis';
          if (double.tryParse(v) == null) return 'Invalide';
          return null;
        },
      ),
    );
  }

  void _confirmDelete() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Supprimer'),
        content: const Text('Supprimer ce produit ?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          ElevatedButton(
            onPressed: () async {
              await _dao.delete(widget.produit!.id!);
              if (mounted) { Navigator.pop(ctx); Navigator.pop(context, true); }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Supprimer'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _nomCtrl.dispose(); _refCtrl.dispose(); _prixAchatCtrl.dispose();
    _prixVenteCtrl.dispose(); _stockCtrl.dispose(); _stockMinCtrl.dispose();
    super.dispose();
  }
}

import 'package:flutter/material.dart';
import '../../database/daos.dart';
import '../../models/models.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _dao = UserDao();
  List<User> _users = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    final data = await _dao.getAll();
    if (mounted) setState(() { _users = data; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Paramètres')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              children: [
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('Gestion des utilisateurs',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
                ..._users.map((u) => Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: u.isAdmin ? Colors.blue.shade100 : Colors.grey.shade100,
                      child: Icon(u.isAdmin ? Icons.admin_panel_settings : Icons.person,
                          color: u.isAdmin ? Colors.blue : Colors.grey),
                    ),
                    title: Text(u.nom),
                    subtitle: Text('${u.login} • ${u.isAdmin ? 'Admin' : 'Employé'}'),
                    trailing: !u.isAdmin
                        ? IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _confirmDelete(u),
                          )
                        : null,
                  ),
                )),
              ],
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddUser,
        child: const Icon(Icons.person_add),
      ),
    );
  }

  void _showAddUser() {
    final nomCtrl = TextEditingController();
    final loginCtrl = TextEditingController();
    final passCtrl = TextEditingController();
    String role = 'employe';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: Container(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Nouvel utilisateur',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                TextFormField(controller: nomCtrl,
                    decoration: const InputDecoration(labelText: 'Nom complet *')),
                const SizedBox(height: 12),
                TextFormField(controller: loginCtrl,
                    decoration: const InputDecoration(labelText: 'Identifiant *')),
                const SizedBox(height: 12),
                TextFormField(controller: passCtrl,
                    obscureText: true,
                    decoration: const InputDecoration(labelText: 'Mot de passe *')),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: role,
                  decoration: const InputDecoration(labelText: 'Rôle'),
                  items: const [
                    DropdownMenuItem(value: 'admin', child: Text('Administrateur')),
                    DropdownMenuItem(value: 'employe', child: Text('Employé')),
                  ],
                  onChanged: (v) => setS(() => role = v!),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      if (nomCtrl.text.isEmpty || loginCtrl.text.isEmpty || passCtrl.text.isEmpty) return;
                      await _dao.insert(User(
                        nom: nomCtrl.text.trim(),
                        login: loginCtrl.text.trim(),
                        password: passCtrl.text,
                        role: role,
                      ));
                      if (ctx.mounted) Navigator.pop(ctx);
                      _loadData();
                    },
                    child: const Text('CRÉER'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _confirmDelete(User u) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Supprimer'),
        content: Text('Supprimer l\'utilisateur "${u.nom}" ?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          ElevatedButton(
            onPressed: () async {
              await _dao.delete(u.id!);
              if (ctx.mounted) Navigator.pop(ctx);
              _loadData();
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Supprimer'),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../../database/daos.dart';
import '../../models/models.dart';
import 'remboursement_screen.dart';

class ClientsScreen extends StatefulWidget {
  const ClientsScreen({super.key});

  @override
  State<ClientsScreen> createState() => _ClientsScreenState();
}

class _ClientsScreenState extends State<ClientsScreen> {
  final _dao = ClientDao();
  List<Client> _clients = [];
  bool _loading = true;
  bool _creditOnly = false;
  final _fmt = NumberFormat('#,##0', 'fr_FR');

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    final data = await _dao.getAll(avecCreditOnly: _creditOnly);
    if (mounted) setState(() { _clients = data; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              const Text('Avec crédit uniquement'),
              const SizedBox(width: 8),
              Switch(
                value: _creditOnly,
                onChanged: (v) { setState(() => _creditOnly = v); _loadData(); },
              ),
            ]),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: _loadData,
                    child: _clients.isEmpty
                        ? const Center(child: Text('Aucun client'))
                        : ListView.builder(
                            itemCount: _clients.length,
                            itemBuilder: (ctx, i) => _buildCard(_clients[i]),
                          ),
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showClientForm(),
        child: const Icon(Icons.person_add),
      ),
    );
  }

  Widget _buildCard(Client c) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: c.creditTotal > 0
              ? Colors.orange.shade100
              : Colors.blue.shade100,
          child: Icon(Icons.person,
              color: c.creditTotal > 0 ? Colors.orange : Colors.blue),
        ),
        title: Text(c.nom, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (c.telephone != null) Text('📞 ${c.telephone}'),
            if (c.adresse != null) Text('📍 ${c.adresse}'),
          ],
        ),
        trailing: c.creditTotal > 0
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text('Crédit dû', style: TextStyle(fontSize: 11, color: Colors.grey)),
                  Text('${_fmt.format(c.creditTotal)} F',
                      style: const TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
                ],
              )
            : const Icon(Icons.check_circle, color: Colors.green),
        onTap: () => _showClientDetail(c),
      ),
    );
  }

  void _showClientForm({Client? client}) {
    final nomCtrl = TextEditingController(text: client?.nom ?? '');
    final telCtrl = TextEditingController(text: client?.telephone ?? '');
    final adrCtrl = TextEditingController(text: client?.adresse ?? '');

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(client == null ? 'Nouveau client' : 'Modifier client',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              TextFormField(controller: nomCtrl,
                  decoration: const InputDecoration(labelText: 'Nom *')),
              const SizedBox(height: 12),
              TextFormField(controller: telCtrl,
                  decoration: const InputDecoration(labelText: 'Téléphone'),
                  keyboardType: TextInputType.phone),
              const SizedBox(height: 12),
              TextFormField(controller: adrCtrl,
                  decoration: const InputDecoration(labelText: 'Adresse')),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () async {
                    if (nomCtrl.text.trim().isEmpty) return;
                    final c = Client(
                      id: client?.id,
                      nom: nomCtrl.text.trim(),
                      telephone: telCtrl.text.trim().isEmpty ? null : telCtrl.text.trim(),
                      adresse: adrCtrl.text.trim().isEmpty ? null : adrCtrl.text.trim(),
                      creditTotal: client?.creditTotal ?? 0,
                    );
                    if (client == null) await _dao.insert(c);
                    else await _dao.update(c);
                    if (ctx.mounted) Navigator.pop(ctx);
                    _loadData();
                  },
                  child: Text(client == null ? 'ENREGISTRER' : 'MODIFIER'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showClientDetail(Client c) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(c.nom, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () { Navigator.pop(ctx); _showClientForm(client: c); },
              ),
            ]),
            if (c.telephone != null) Text('📞 ${c.telephone}'),
            if (c.adresse != null) Text('📍 ${c.adresse}'),
            const Divider(),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('Crédit en cours:', style: TextStyle(fontWeight: FontWeight.bold)),
              Text('${_fmt.format(c.creditTotal)} FCFA',
                  style: TextStyle(
                      color: c.creditTotal > 0 ? Colors.orange : Colors.green,
                      fontWeight: FontWeight.bold, fontSize: 18)),
            ]),
            if (c.creditTotal > 0) ...[
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.payments),
                  label: const Text('Enregistrer un remboursement'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                  onPressed: () async {
                    Navigator.pop(context);
                    final result = await Navigator.push(context,
                        MaterialPageRoute(
                            builder: (_) => RemboursementScreen(client: c)));
                    if (result == true) _loadData();
                  },
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

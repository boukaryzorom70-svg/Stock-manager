import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../database/daos.dart';
import '../../models/models.dart';

class RemboursementScreen extends StatefulWidget {
  final Client client;
  const RemboursementScreen({super.key, required this.client});

  @override
  State<RemboursementScreen> createState() => _RemboursementScreenState();
}

class _RemboursementScreenState extends State<RemboursementScreen> {
  final _formKey = GlobalKey<FormState>();
  final _montantCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  bool _loading = false;
  final _fmt = NumberFormat('#,##0', 'fr_FR');

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final montant = double.parse(_montantCtrl.text);
    if (montant > widget.client.creditTotal) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Le montant dépasse le crédit en cours'),
          backgroundColor: Colors.red));
      return;
    }

    setState(() => _loading = true);
    final userId = context.read<AuthProvider>().currentUser!.id!;

    // Mettre à jour le crédit client
    final clientDao = ClientDao();
    await clientDao.updateCredit(widget.client.id!, -montant);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('✅ Remboursement enregistré'),
          backgroundColor: Colors.green));
      Navigator.pop(context, true);
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Remboursement crédit')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Info client
              Card(
                color: Colors.orange.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      const Icon(Icons.person, color: Colors.orange),
                      const SizedBox(width: 12),
                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(widget.client.nom,
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        Text('Crédit en cours: ${_fmt.format(widget.client.creditTotal)} FCFA',
                            style: const TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
                      ]),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              TextFormField(
                controller: _montantCtrl,
                decoration: const InputDecoration(
                  labelText: 'Montant remboursé (FCFA) *',
                  prefixIcon: Icon(Icons.payments),
                ),
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Requis';
                  if (double.tryParse(v) == null) return 'Invalide';
                  if (double.parse(v) <= 0) return 'Montant doit être positif';
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _noteCtrl,
                decoration: const InputDecoration(
                  labelText: 'Note (optionnel)',
                  prefixIcon: Icon(Icons.note),
                ),
              ),
              const SizedBox(height: 32),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _loading ? null : _save,
                  icon: _loading
                      ? const SizedBox(width: 20, height: 20,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : const Icon(Icons.check),
                  label: const Text('ENREGISTRER LE REMBOURSEMENT'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() { _montantCtrl.dispose(); _noteCtrl.dispose(); super.dispose(); }
}

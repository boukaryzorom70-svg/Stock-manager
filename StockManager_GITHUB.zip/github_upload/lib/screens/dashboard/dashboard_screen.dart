import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../database/daos.dart';
import '../../models/models.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final _dashDao = DashboardDao();
  final _produitDao = ProduitDao();
  String _periode = 'today';
  Map<String, dynamic>? _stats;
  List<Produit> _alertes = [];
  bool _loading = true;

  final _fmt = NumberFormat('#,##0', 'fr_FR');

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    final now = DateTime.now();
    String debut, fin;

    switch (_periode) {
      case 'today':
        debut = fin = DateFormat('yyyy-MM-dd').format(now);
        break;
      case 'month':
        debut = DateFormat('yyyy-MM-01').format(now);
        fin = DateFormat('yyyy-MM-dd').format(now);
        break;
      case 'year':
        debut = '${now.year}-01-01';
        fin = DateFormat('yyyy-MM-dd').format(now);
        break;
      default:
        debut = fin = DateFormat('yyyy-MM-dd').format(now);
    }

    final stats = await _dashDao.getStats(dateDebut: debut, dateFin: fin);
    final alertes = await _produitDao.getStockFaible();

    if (mounted) setState(() { _stats = stats; _alertes = alertes; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    final isAdmin = context.watch<AuthProvider>().isAdmin;

    return RefreshIndicator(
      onRefresh: _loadData,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Sélecteur période
            Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    const Icon(Icons.calendar_today, size: 18),
                    const SizedBox(width: 8),
                    const Text('Période :'),
                    const SizedBox(width: 8),
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'today', label: Text('Auj.')),
                        ButtonSegment(value: 'month', label: Text('Mois')),
                        ButtonSegment(value: 'year', label: Text('Année')),
                      ],
                      selected: {_periode},
                      onSelectionChanged: (s) {
                        setState(() => _periode = s.first);
                        _loadData();
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),

            if (_loading)
              const Center(child: CircularProgressIndicator())
            else if (_stats != null) ...[
              // Cartes statistiques
              _buildStatCard('Chiffre d\'Affaires',
                  '${_fmt.format(_stats!['chiffre_affaires'])} FCFA',
                  Icons.trending_up, Colors.blue),
              if (isAdmin)
                _buildStatCard('Bénéfice',
                    '${_fmt.format(_stats!['benefice'])} FCFA',
                    Icons.monetization_on, Colors.green),
              _buildStatCard('Encaissé',
                  '${_fmt.format(_stats!['encaisse'])} FCFA',
                  Icons.payments, Colors.teal),
              _buildStatCard('Crédit (ventes)',
                  '${_fmt.format(_stats!['en_credit'])} FCFA',
                  Icons.credit_card, Colors.orange),
              _buildStatCard('Nb Ventes',
                  '${_stats!['nb_ventes']} vente(s)',
                  Icons.receipt_long, Colors.purple),
              if (isAdmin)
                _buildStatCard('Crédits clients (total)',
                    '${_fmt.format(_stats!['total_credit_clients'])} FCFA',
                    Icons.account_balance_wallet, Colors.red),

              // Alertes stock
              if (_alertes.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text('⚠️ Alertes Stock (${_alertes.length})',
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold, color: Colors.orange)),
                const SizedBox(height: 8),
                ..._alertes.map((p) => Card(
                  color: p.isRupture ? Colors.red.shade50 : Colors.orange.shade50,
                  child: ListTile(
                    leading: Icon(
                      p.isRupture ? Icons.error : Icons.warning,
                      color: p.isRupture ? Colors.red : Colors.orange,
                    ),
                    title: Text(p.nom),
                    subtitle: Text(p.categorieNom ?? ''),
                    trailing: Text(
                      '${p.stockActuel} ${p.unite}',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: p.isRupture ? Colors.red : Colors.orange),
                    ),
                  ),
                )),
              ],
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.15),
          child: Icon(icon, color: color),
        ),
        title: Text(title, style: const TextStyle(fontSize: 13, color: Colors.grey)),
        trailing: Text(value,
            style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.bold, color: color)),
      ),
    );
  }
}

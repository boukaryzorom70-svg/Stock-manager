import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../../database/daos.dart';
import '../../models/models.dart';

class NouvelleVenteScreen extends StatefulWidget {
  final int userId;
  const NouvelleVenteScreen({super.key, required this.userId});

  @override
  State<NouvelleVenteScreen> createState() => _NouvelleVenteScreenState();
}

class _NouvelleVenteScreenState extends State<NouvelleVenteScreen> {
  final _produitDao = ProduitDao();
  final _clientDao = ClientDao();
  final _venteDao = VenteDao();

  List<Produit> _produits = [];
  List<Client> _clients = [];
  Client? _selectedClient;
  String _typePaiement = 'comptant';
  final _montantPayeCtrl = TextEditingController();

  // Panier
  final List<Map<String, dynamic>> _panier = [];

  bool _loading = false;
  final _fmt = NumberFormat('#,##0', 'fr_FR');

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prods = await _produitDao.getAll();
    final clients = await _clientDao.getAll();
    if (mounted) setState(() { _produits = prods; _clients = clients; });
  }

  double get _totalPanier =>
      _panier.fold(0, (sum, item) => sum + (item['sousTotal'] as double));

  void _addToPanier(Produit produit, double qte) {
    // Vérifier si produit déjà dans le panier
    final idx = _panier.indexWhere((i) => i['produit'].id == produit.id);
    final sousTotal = qte * produit.prixVente;

    if (idx >= 0) {
      setState(() {
        _panier[idx]['quantite'] = (_panier[idx]['quantite'] as double) + qte;
        _panier[idx]['sousTotal'] =
            (_panier[idx]['quantite'] as double) * produit.prixVente;
      });
    } else {
      setState(() => _panier.add({
        'produit': produit,
        'quantite': qte,
        'prixVente': produit.prixVente,
        'prixAchat': produit.prixAchat,
        'sousTotal': sousTotal,
      }));
    }
  }

  void _removeFromPanier(int index) => setState(() => _panier.removeAt(index));

  Future<void> _finaliserVente() async {
    if (_panier.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Le panier est vide')));
      return;
    }

    final montantPaye = _typePaiement == 'comptant'
        ? _totalPanier
        : _typePaiement == 'credit'
            ? 0.0
            : double.tryParse(_montantPayeCtrl.text) ?? 0;

    if (_typePaiement != 'comptant' && _selectedClient == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Sélectionnez un client pour le crédit')));
      return;
    }

    setState(() => _loading = true);

    final vente = Vente(
      numero: '',
      clientId: _selectedClient?.id,
      typePaiement: _typePaiement,
      montantTotal: _totalPanier,
      montantPaye: montantPaye,
      montantCredit: _totalPanier - montantPaye,
      userId: widget.userId,
    );

    final lignes = _panier.map((item) => VenteLigne(
      venteId: 0,
      produitId: (item['produit'] as Produit).id!,
      quantite: item['quantite'] as double,
      prixVente: item['prixVente'] as double,
      prixAchat: item['prixAchat'] as double,
      sousTotal: item['sousTotal'] as double,
    )).toList();

    try {
      await _venteDao.insert(vente, lignes);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('✅ Vente enregistrée avec succès'),
                backgroundColor: Colors.green));
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Erreur: $e'), backgroundColor: Colors.red));
      }
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nouvelle Vente')),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Sélection client
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Client', style: TextStyle(fontWeight: FontWeight.bold)),
                          DropdownButtonFormField<Client>(
                            value: _selectedClient,
                            decoration: const InputDecoration(hintText: 'Client (optionnel)'),
                            items: [
                              const DropdownMenuItem(value: null, child: Text('— Aucun client —')),
                              ..._clients.map((c) =>
                                  DropdownMenuItem(value: c, child: Text(c.nom))),
                            ],
                            onChanged: (c) => setState(() => _selectedClient = c),
                          ),
                          const SizedBox(height: 12),
                          const Text('Mode de paiement', style: TextStyle(fontWeight: FontWeight.bold)),
                          SegmentedButton<String>(
                            segments: const [
                              ButtonSegment(value: 'comptant', label: Text('Comptant')),
                              ButtonSegment(value: 'credit', label: Text('Crédit')),
                              ButtonSegment(value: 'mixte', label: Text('Mixte')),
                            ],
                            selected: {_typePaiement},
                            onSelectionChanged: (s) => setState(() => _typePaiement = s.first),
                          ),
                          if (_typePaiement == 'mixte') ...[
                            const SizedBox(height: 12),
                            TextFormField(
                              controller: _montantPayeCtrl,
                              decoration: const InputDecoration(
                                  labelText: 'Montant payé (FCFA)',
                                  prefixIcon: Icon(Icons.payments)),
                              keyboardType: TextInputType.number,
                              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 8),

                  // Ajouter produits
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.add_shopping_cart, color: Colors.blue),
                      title: const Text('Ajouter un produit'),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () => _showAddProduitDialog(),
                    ),
                  ),

                  const SizedBox(height: 8),

                  // Panier
                  if (_panier.isNotEmpty) ...[
                    const Text('🛒 Panier',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 8),
                    ..._panier.asMap().entries.map((entry) {
                      final i = entry.key;
                      final item = entry.value;
                      final p = item['produit'] as Produit;
                      return Card(
                        child: ListTile(
                          title: Text(p.nom),
                          subtitle: Text('${item['quantite']} x ${_fmt.format(item['prixVente'])} F'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('${_fmt.format(item['sousTotal'])} F',
                                  style: const TextStyle(fontWeight: FontWeight.bold)),
                              IconButton(
                                icon: const Icon(Icons.delete, color: Colors.red, size: 20),
                                onPressed: () => _removeFromPanier(i),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                  ],
                ],
              ),
            ),
          ),

          // Bas : total + bouton
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8)],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('TOTAL', style: TextStyle(color: Colors.grey)),
                      Text('${_fmt.format(_totalPanier)} FCFA',
                          style: const TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold,
                              color: Color(0xFF1565C0))),
                    ],
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: _loading ? null : _finaliserVente,
                  icon: _loading
                      ? const SizedBox(width: 20, height: 20,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : const Icon(Icons.check),
                  label: const Text('VALIDER'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showAddProduitDialog() {
    Produit? selected;
    final qteCtrl = TextEditingController(text: '1');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Ajouter un produit'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<Produit>(
              decoration: const InputDecoration(labelText: 'Produit'),
              items: _produits
                  .where((p) => p.stockActuel > 0)
                  .map((p) => DropdownMenuItem(
                    value: p,
                    child: Text('${p.nom} (Stock: ${p.stockActuel})'),
                  ))
                  .toList(),
              onChanged: (p) => selected = p,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: qteCtrl,
              decoration: const InputDecoration(labelText: 'Quantité'),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          ElevatedButton(
            onPressed: () {
              if (selected == null) return;
              final qte = double.tryParse(qteCtrl.text) ?? 1;
              if (qte <= 0 || qte > selected!.stockActuel) {
                ScaffoldMessenger.of(ctx).showSnackBar(
                    const SnackBar(content: Text('Quantité invalide ou insuffisante')));
                return;
              }
              _addToPanier(selected!, qte);
              Navigator.pop(ctx);
            },
            child: const Text('Ajouter'),
          ),
        ],
      ),
    );
  }
}

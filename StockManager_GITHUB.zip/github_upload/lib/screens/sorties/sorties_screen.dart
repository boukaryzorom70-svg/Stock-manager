import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../database/daos.dart';
import '../../models/models.dart';
import 'nouvelle_vente_screen.dart';

import '../../services/pdf_service.dart';

class SortiesScreen extends StatefulWidget {
  const SortiesScreen({super.key});

  @override
  State<SortiesScreen> createState() => _SortiesScreenState();
}

class _SortiesScreenState extends State<SortiesScreen> {
  final _dao = VenteDao();
  List<Vente> _ventes = [];
  bool _loading = true;
  final _fmt = NumberFormat('#,##0', 'fr_FR');
  final _dateFmt = DateFormat('dd/MM/yyyy HH:mm');

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    final data = await _dao.getAll();
    if (mounted) setState(() { _ventes = data; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    final isAdmin = context.watch<AuthProvider>().isAdmin;

    return Scaffold(
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadData,
              child: _ventes.isEmpty
                  ? const Center(child: Text('Aucune vente enregistrée'))
                  : ListView.builder(
                      itemCount: _ventes.length,
                      itemBuilder: (ctx, i) => _buildCard(_ventes[i], isAdmin),
                    ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final user = context.read<AuthProvider>().currentUser!;
          await Navigator.push(context,
              MaterialPageRoute(builder: (_) => NouvelleVenteScreen(userId: user.id!)));
          _loadData();
        },
        icon: const Icon(Icons.shopping_cart),
        label: const Text('Nouvelle vente'),
      ),
    );
  }

  Widget _buildCard(Vente v, bool isAdmin) {
    final color = v.isAnnulee ? Colors.grey : Colors.blue;
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.15),
          child: Icon(
            v.typePaiement == 'credit' ? Icons.credit_card : Icons.payments,
            color: color,
          ),
        ),
        title: Row(children: [
          Text(v.numero, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          const SizedBox(width: 8),
          if (v.isAnnulee)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.red.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text('ANNULÉE', style: TextStyle(color: Colors.red, fontSize: 10)),
            ),
        ]),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (v.clientNom != null) Text('Client: ${v.clientNom}'),
            Text('${_capitalize(v.typePaiement)} | ${v.userNom}'),
            Text(v.createdAt != null ? _dateFmt.format(DateTime.parse(v.createdAt!)) : '',
                style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text('${_fmt.format(v.montantTotal)} F',
                style: TextStyle(fontWeight: FontWeight.bold, color: color)),
            if (v.montantCredit > 0)
              Text('Crédit: ${_fmt.format(v.montantCredit)} F',
                  style: const TextStyle(color: Colors.orange, fontSize: 11)),
          ],
        ),
        onTap: () => _showVenteDetail(v, isAdmin),
      ),
    );
  }

  void _showVenteDetail(Vente v, bool isAdmin) async {
    final detail = await _dao.getById(v.id!);
    if (!mounted || detail == null) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => VenteDetailSheet(
        vente: detail,
        isAdmin: isAdmin,
        onAnnuler: () async {
          final user = context.read<AuthProvider>().currentUser!;
          await _dao.annuler(detail.id!, user.id!);
          Navigator.pop(context);
          _loadData();
        },
      ),
    );
  }

  String _capitalize(String s) => s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);
}

class VenteDetailSheet extends StatelessWidget {
  final Vente vente;
  final bool isAdmin;
  final VoidCallback onAnnuler;

  const VenteDetailSheet({
    super.key,
    required this.vente,
    required this.isAdmin,
    required this.onAnnuler,
  });

  @override
  Widget build(BuildContext context) {
    final fmt = NumberFormat('#,##0', 'fr_FR');

    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      expand: false,
      builder: (ctx, scroll) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(vente.numero, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              if (!vente.isAnnulee && isAdmin)
                ElevatedButton.icon(
                  icon: const Icon(Icons.cancel),
                  label: const Text('Annuler'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (d) => AlertDialog(
                        title: const Text('Annuler la vente ?'),
                        content: const Text('Le stock sera remis à jour.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Non')),
                          ElevatedButton(
                            onPressed: () { Navigator.pop(d); onAnnuler(); },
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                            child: const Text('Oui, annuler'),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              IconButton(
                icon: const Icon(Icons.picture_as_pdf, color: Colors.red),
                tooltip: 'Générer facture PDF',
                onPressed: () => PdfService.genererFacture(vente),
              ),
            ]),
            const Divider(),
            Expanded(
              child: ListView(
                controller: scroll,
                children: [
                  if (vente.clientNom != null) _row('Client', vente.clientNom!),
                  _row('Type', vente.typePaiement),
                  _row('Total', '${fmt.format(vente.montantTotal)} FCFA'),
                  _row('Payé', '${fmt.format(vente.montantPaye)} FCFA'),
                  if (vente.montantCredit > 0)
                    _row('Crédit', '${fmt.format(vente.montantCredit)} FCFA'),
                  const Divider(),
                  const Text('Articles:', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  ...vente.lignes.map((l) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(child: Text('${l.produitNom} x${l.quantite}')),
                        Text('${fmt.format(l.sousTotal)} F',
                            style: const TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                  )),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: const TextStyle(color: Colors.grey)),
      Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
    ]),
  );
}

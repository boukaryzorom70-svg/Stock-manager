import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../database/daos.dart';
import '../../models/models.dart';

class EntreesScreen extends StatefulWidget {
  const EntreesScreen({super.key});

  @override
  State<EntreesScreen> createState() => _EntreesScreenState();
}

class _EntreesScreenState extends State<EntreesScreen> {
  final _dao = EntreeDao();
  List<Entree> _entrees = [];
  bool _loading = true;
  final _fmt = NumberFormat('#,##0', 'fr_FR');
  final _dateFmt = DateFormat('dd/MM/yyyy HH:mm');

  @override
  void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    final data = await _dao.getAll();
    if (mounted) setState(() { _entrees = data; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadData,
              child: _entrees.isEmpty
                  ? const Center(child: Text('Aucune entrée enregistrée'))
                  : ListView.builder(
                      itemCount: _entrees.length,
                      itemBuilder: (ctx, i) => _buildCard(_entrees[i]),
                    ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            builder: (_) => NouvelleEntreeSheet(userId: context.read<AuthProvider>().currentUser!.id!),
          );
          _loadData();
        },
        icon: const Icon(Icons.add),
        label: const Text('Nouvelle entrée'),
      ),
    );
  }

  Widget _buildCard(Entree e) {
    return Card(
      child: ListTile(
        leading: const CircleAvatar(
          backgroundColor: Color(0xFFE8F5E9),
          child: Icon(Icons.add_circle, color: Colors.green),
        ),
        title: Text(e.produitNom ?? '', style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Qté: ${e.quantite} | Prix: ${_fmt.format(e.prixAchat)} FCFA'),
            if (e.fournisseur != null) Text('Fournisseur: ${e.fournisseur}'),
            Text(e.createdAt != null ? _dateFmt.format(DateTime.parse(e.createdAt!)) : '',
                style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
          ],
        ),
        trailing: Text('${_fmt.format(e.montantTotal)} F',
            style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
      ),
    );
  }
}

class NouvelleEntreeSheet extends StatefulWidget {
  final int userId;
  const NouvelleEntreeSheet({super.key, required this.userId});

  @override
  State<NouvelleEntreeSheet> createState() => _NouvelleEntreeSheetState();
}

class _NouvelleEntreeSheetState extends State<NouvelleEntreeSheet> {
  final _formKey = GlobalKey<FormState>();
  final _produitDao = ProduitDao();
  final _entreeDao = EntreeDao();
  List<Produit> _produits = [];
  Produit? _selectedProduit;
  final _qteCtrl = TextEditingController();
  final _prixCtrl = TextEditingController();
  final _fournCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _produitDao.getAll().then((p) => setState(() => _produits = p));
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate() || _selectedProduit == null) return;
    setState(() => _loading = true);

    await _entreeDao.insert(Entree(
      produitId: _selectedProduit!.id!,
      quantite: double.parse(_qteCtrl.text),
      prixAchat: double.parse(_prixCtrl.text),
      fournisseur: _fournCtrl.text.trim().isEmpty ? null : _fournCtrl.text.trim(),
      note: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
      userId: widget.userId,
    ));

    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Nouvelle Entrée de Stock',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              DropdownButtonFormField<Produit>(
                decoration: const InputDecoration(labelText: 'Produit *'),
                items: _produits
                    .map((p) => DropdownMenuItem(value: p, child: Text(p.nom)))
                    .toList(),
                onChanged: (p) {
                  setState(() {
                    _selectedProduit = p;
                    if (p != null) _prixCtrl.text = p.prixAchat.toString();
                  });
                },
                validator: (v) => v == null ? 'Requis' : null,
              ),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _numField(_qteCtrl, 'Quantité *')),
                const SizedBox(width: 12),
                Expanded(child: _numField(_prixCtrl, 'Prix achat *')),
              ]),
              _textField(_fournCtrl, 'Fournisseur'),
              _textField(_noteCtrl, 'Note'),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _loading ? null : _save,
                  child: _loading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('ENREGISTRER'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _numField(TextEditingController ctrl, String label) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextFormField(
      controller: ctrl,
      decoration: InputDecoration(labelText: label),
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[\d.]'))],
      validator: (v) => v == null || v.isEmpty ? 'Requis' : null,
    ),
  );

  Widget _textField(TextEditingController ctrl, String label) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextFormField(controller: ctrl, decoration: InputDecoration(labelText: label)),
  );
}

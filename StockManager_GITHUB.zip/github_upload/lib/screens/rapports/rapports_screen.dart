import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../database/daos.dart';
import '../../models/models.dart';
import '../../services/pdf_service.dart';

class RapportsScreen extends StatefulWidget {
  const RapportsScreen({super.key});

  @override
  State<RapportsScreen> createState() => _RapportsScreenState();
}

class _RapportsScreenState extends State<RapportsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  final _dashDao = DashboardDao();
  final _venteDao = VenteDao();
  final _fmt = NumberFormat('#,##0', 'fr_FR');
  final _dateFmt = DateFormat('dd/MM/yyyy');

  DateTime _dateDebut = DateTime.now();
  DateTime _dateFin = DateTime.now();
  Map<String, dynamic>? _stats;
  List<Vente> _ventes = [];
  bool _loading = false;
  bool _exporting = false;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    final debut = DateFormat('yyyy-MM-dd').format(_dateDebut);
    final fin = DateFormat('yyyy-MM-dd').format(_dateFin);

    final stats = await _dashDao.getStats(dateDebut: debut, dateFin: fin);
    final ventes = await _venteDao.getAll(dateDebut: debut, dateFin: fin, statut: 'active');

    if (mounted) setState(() { _stats = stats; _ventes = ventes; _loading = false; });
  }

  Future<void> _exporterPDF() async {
    if (_stats == null) return;
    setState(() => _exporting = true);
    final isAdmin = context.read<AuthProvider>().isAdmin;
    final date = '${_dateFmt.format(_dateDebut)} - ${_dateFmt.format(_dateFin)}';
    try {
      await PdfService.genererRapportJournalier(
        stats: _stats!,
        ventes: _ventes,
        date: date,
        isAdmin: isAdmin,
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Erreur PDF: $e'), backgroundColor: Colors.red));
      }
    }
    if (mounted) setState(() => _exporting = false);
  }

  @override
  Widget build(BuildContext context) {
    final isAdmin = context.watch<AuthProvider>().isAdmin;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Rapports'),
        actions: [
          IconButton(
            icon: _exporting
                ? const SizedBox(width: 20, height: 20,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Icon(Icons.picture_as_pdf),
            onPressed: _exporting ? null : _exporterPDF,
            tooltip: 'Exporter PDF',
          ),
        ],
        bottom: TabBar(
          controller: _tabCtrl,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          tabs: const [
            Tab(text: 'Résumé'),
            Tab(text: 'Ventes'),
            Tab(text: 'Stock'),
          ],
        ),
      ),
      body: Column(
        children: [
          // Sélecteur de dates
          _buildDateSelector(),

          // Tabs
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : TabBarView(
                    controller: _tabCtrl,
                    children: [
                      _buildResumeTab(isAdmin),
                      _buildVentesTab(),
                      _buildStockTab(),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildDateSelector() {
    return Card(
      margin: const EdgeInsets.all(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: [
            Expanded(
              child: InkWell(
                onTap: () => _pickDate(isDebut: true),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Du', style: TextStyle(fontSize: 11, color: Colors.grey)),
                    Text(_dateFmt.format(_dateDebut),
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
            const Icon(Icons.arrow_forward, size: 16, color: Colors.grey),
            Expanded(
              child: InkWell(
                onTap: () => _pickDate(isDebut: false),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('Au', style: TextStyle(fontSize: 11, color: Colors.grey)),
                    Text(_dateFmt.format(_dateFin),
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: _loadData,
              style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8)),
              child: const Text('OK'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResumeTab(bool isAdmin) {
    if (_stats == null) return const Center(child: Text('Aucune donnée'));
    return SingleChildScrollView(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          _bigStatCard('Chiffre d\'Affaires',
              '${_fmt.format(_stats!['chiffre_affaires'])} FCFA',
              Icons.trending_up, Colors.blue),
          _bigStatCard('Ventes réalisées',
              '${_stats!['nb_ventes']} vente(s)',
              Icons.receipt_long, Colors.indigo),
          _bigStatCard('Montant encaissé',
              '${_fmt.format(_stats!['encaisse'])} FCFA',
              Icons.payments, Colors.teal),
          _bigStatCard('En crédit',
              '${_fmt.format(_stats!['en_credit'])} FCFA',
              Icons.credit_card, Colors.orange),
          if (isAdmin) ...[
            _bigStatCard('Bénéfice net',
                '${_fmt.format(_stats!['benefice'])} FCFA',
                Icons.monetization_on, Colors.green),
            _bigStatCard('Total crédits clients',
                '${_fmt.format(_stats!['total_credit_clients'])} FCFA',
                Icons.account_balance_wallet, Colors.red),
          ],
          if (isAdmin && _stats!['chiffre_affaires'] > 0) ...[
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text('Taux de bénéfice',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text(
                      '${((_stats!['benefice'] / _stats!['chiffre_affaires']) * 100).toStringAsFixed(1)}%',
                      style: const TextStyle(
                          fontSize: 32, fontWeight: FontWeight.bold,
                          color: Colors.green),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildVentesTab() {
    if (_ventes.isEmpty) {
      return const Center(child: Text('Aucune vente sur cette période'));
    }
    return ListView.builder(
      itemCount: _ventes.length,
      itemBuilder: (ctx, i) {
        final v = _ventes[i];
        return Card(
          child: ListTile(
            title: Text(v.numero,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            subtitle: Text(
              '${v.clientNom ?? 'Client comptoir'} • ${v.typePaiement}',
            ),
            trailing: Text('${_fmt.format(v.montantTotal)} F',
                style: const TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.blue)),
          ),
        );
      },
    );
  }

  Widget _buildStockTab() {
    return FutureBuilder<List>(
      future: ProduitDao().getAll(),
      builder: (ctx, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final produits = snap.data!;
        return ListView.builder(
          itemCount: produits.length,
          itemBuilder: (ctx, i) {
            final p = produits[i];
            Color c = p.isRupture ? Colors.red : p.isStockFaible ? Colors.orange : Colors.green;
            return Card(
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: c.withOpacity(0.15),
                  child: Icon(Icons.inventory_2, color: c, size: 20),
                ),
                title: Text(p.nom),
                subtitle: Text(p.categorieNom ?? ''),
                trailing: Text('${p.stockActuel} ${p.unite}',
                    style: TextStyle(color: c, fontWeight: FontWeight.bold)),
              ),
            );
          },
        );
      },
    );
  }

  Widget _bigStatCard(String title, String value, IconData icon, Color color) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.15),
          radius: 24,
          child: Icon(icon, color: color),
        ),
        title: Text(title, style: const TextStyle(fontSize: 13, color: Colors.grey)),
        trailing: Text(value,
            style: TextStyle(
                fontSize: 15, fontWeight: FontWeight.bold, color: color)),
      ),
    );
  }

  Future<void> _pickDate({required bool isDebut}) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: isDebut ? _dateDebut : _dateFin,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        if (isDebut) _dateDebut = picked;
        else _dateFin = picked;
      });
    }
  }

  @override
  void dispose() { _tabCtrl.dispose(); super.dispose(); }
}
